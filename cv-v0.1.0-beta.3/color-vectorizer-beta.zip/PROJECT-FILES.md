# Save and open an editable project

**Save Project** downloads a `.color-project.json` file. **Open Project** restores
it; project files can also be dropped onto the page.

The file embeds the source image and material photo, tracing/filter settings,
art and material dimensions, units, placement, aspect lock, section layout,
recipe selection and alignment-guide toggle. Vectors are rebuilt from the saved
source and settings on open. An empty-result project can still be opened to
adjust its filters.

This is different from SVG/Engrave Pack export: those are output files, not
editable project backups. Work is not automatically saved to the cloud or
browser storage. Keep the downloaded project file before closing the browser.
After a download starts, verify that it reached your Downloads folder.

Unsaved changes warn before leaving or reloading. Opening a project asks before
replacing unsaved work. Invalid files, unsupported versions, broken embedded
images and files over 80 MB are rejected without replacing your work. Both
apps use their own versioned file formats; an Engraving Prep project is not a
Color Vectorizer project.

Recipe selection is saved, but this does not validate any laser settings or
guarantee material colors. Alignment guides remain real geometry when enabled.

Typed Left/Top values update the material previews and margins immediately.
Typed artwork widths retain thousandth-mm precision in the SVG; generated
heights are rounded to hundredth-mm precision. Millimetre fields show two decimals.
The default 3.50-inch width is 88.9 mm. Placement changes participate in Undo/Redo.

Phone-width browser layouts keep the main controls reachable; real iOS/Android
touch, file-picker and download behavior still needs device verification.

Run checks with:

```bash
node --test tests/*.cjs
```
