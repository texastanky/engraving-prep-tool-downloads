# Color Vectorizer browser beta

This candidate includes portable project files, precise artwork dimensions,
live typed placement and optional layer alignment guides.

Download the artifact from the successful **Browser beta candidate** Actions
run. Extract it, then extract `color-vectorizer-beta.zip` into its own folder.
Open `index.html` in Chrome or Edge, or use the included Windows launcher.
No installer or local server is required. The source commit is included for
identifying the exact candidate. CI artifacts expire after 14 days and inherit
repository visibility. No website or public release is deployed.

## Acceptance checklist

- Load Sample, then a real PNG. Check original and vector previews.
- For artwork with white details, confirm Ignore white background is intentional.
- Set width 3.33 inches; Art-Only SVG width should be 84.582 mm.
- Type Left 1.50 and Top 2.00 inches. Preview margins and Layout SVG should agree;
  the exported placement should be 38.1 and 50.8 mm.
- Save a `.color-project.json` file, close the browser and reopen that project.
  Check the source, vector settings, size, position and optional material photo.
- Cancel replacing unsaved work and try an invalid project file. Current work
  should remain unchanged.
- Import combined and separate-layer SVGs into your laser software and verify size,
  alignment and independent color selection. Start with alignment guides OFF;
  enabled guides are real engraving geometry and must not be overlooked.
- Repeat with one real design before approving a release.

SVG exports are outputs, not editable project backups. Save Project is the
backup. Recipes are test starting points, not verified titanium/stainless colors.
Mobile optimization and material-color calibration remain deferred.
